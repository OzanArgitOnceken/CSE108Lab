#include <stdio.h>

int main()
{
    int r1, r2, i1, i2;
    printf("Please enter the first complex number (real part first):\n");
    scanf("%d %d",&r1,&i1);
    printf("Please enter the second complex number (real part first):\n");
    scanf("%d %d",&r2,&i2);
    int sum_r,sum_i, multi_r, multi_i;
    sum_r = r1+r2;
    sum_i = i1+i2;
    multi_r = (r1*r2)+((i1*i2)*-1);
    multi_i = (r1*i2)+(r2*i1);
    printf("Sum of the numbers = %d + (%di)\n",sum_r,sum_i);
    printf("Multiplication of the numbers = %d + (%di)\n",multi_r,multi_i);
    return 0;
}

