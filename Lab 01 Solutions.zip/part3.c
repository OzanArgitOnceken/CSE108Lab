#include <stdio.h>
#define PI 3.14
int main()
{
    double radius;
    printf("Please enter the radius of the circle:\n");
    scanf("%lf",&radius);
    printf("The area of the circle = %.2lf\n", radius * radius * PI);
    printf("The perimeter of the circle = %.2lf\n", 2 * PI * radius);
    return 0;
}
