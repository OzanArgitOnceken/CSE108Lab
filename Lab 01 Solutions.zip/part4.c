#include <stdio.h>
int main()
{
    int t_day=21, t_month=2, t_year=2020;
    int day,month,year;
    printf("Please enter a date in format dd/mm/yy:\n");
    scanf("%d %d %d",&day,&month,&year);
    double day_difference=0;
    day_difference += (year - t_year) * 360;
    day_difference += (month - t_month) * 30;
    day_difference += (day - t_day);
    double sec_difference = day_difference * 86400;
    printf("Entered date is %.0lf seconds far away from now.\n",sec_difference);
    return 0;
}
