#include <stdio.h>

int main()
{
    int n1, n2;
    printf("Please enter two integer numbers:\n");
    scanf("%d %d",&n1,&n2);
    printf("%d + %d = %d\n", n1, n2,n1 + n2);
    printf("%d - %d = %d\n", n1, n2,n1 - n2);
    printf("%d * %d = %d\n", n1, n2,n1 * n2);
    printf("%d / %d = %d\n", n1, n2,n1 / n2);
    printf("%d = %d mod(%d)\n", n1, n1 % n2,n2);
    return 0;
}
