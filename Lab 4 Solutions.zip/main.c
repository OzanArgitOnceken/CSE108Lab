#include <stdio.h>
#include <math.h>

int isEven(int n)
{
  return n%2+1;
}

int isPrime(int n){
  int i = 0;
  
  if (n==2)
    return 1;
  if (isEven(n) == 1 || n == 1)
    return 0;
  for(i=3;i<=sqrt(n);i+=2){
    if( n% i ==0)
      return 0; 
  }
  return 1;
}
int isSemiPrime(int n){
  int i =3;
  int quotient = 0;
  if(isPrime(n))
    return 0;
  for(i=2;i<=sqrt(n);i+=1){
    if( n%i == 0)
     {
       quotient = n /i;
       if(isPrime(quotient) && isPrime(i))
        return 1;
     }
  }
  return 0;

}

int isCoprime(int numberOne,int numberTwo){
  int i =0;
  for(i =2; i< numberTwo;i++){
    if(numberOne %i ==0 && numberTwo %i ==0)
      return 0;
  }
  return 1;
}
int progressionSeries(int n){
  int step = 0;
  int numberOfPrimes = 0;
  int numberofCoPrimes = 0;

  while(n!=1){
      numberOfPrimes = 0;
      numberofCoPrimes = 0;
      step++;
       for(int i = 2; i<= n;i++){
          if(isPrime(i)){
           numberOfPrimes+=1;            
          }
          
          if(isCoprime(n, i)){
            numberofCoPrimes +=1;
          }
        } 
      printf("%d \t %d \t %d \%d\n",step,n,numberOfPrimes,numberofCoPrimes);
      if(isEven(n) == 1)
        n = n/2;
      else
        n = 3*n +1;
  }

}

void generate_primes(int start, int end, int *primeCount,int *semiPrimeCount){

  for(int i = start; i<= end;i++){
    if(isPrime(i)){
      printf("%d is Prime\n",i);
      (*primeCount) +=1;
    }
    
    if(isSemiPrime(i)){
      printf("%d is SemiPrime\n",i);
      (*semiPrimeCount) +=1;
    }
  }
}
int main(void) {
  int start = 5;
  int end =20;
  int primeCount =0;
  int semiPrimeCount =0;
  /***********************PART 2 ***********************/
  generate_primes(start,end,&primeCount,&semiPrimeCount);
  printf("Number of primes :%d\n",primeCount);
  printf("Number of semi-primes :%d\n",semiPrimeCount);
  /***********************PART 3 ***********************/
  progressionSeries(13);
  
  return 0;
}