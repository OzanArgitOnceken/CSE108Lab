#include <stdio.h>

int area(int, int);
int perimeter(int, int);

int main()
{
	int l, w;
	printf("Please enter the length of the rectangle:\n");
	scanf("%d", &l);
	
	printf("Please enter the width of the rectangle:\n");
	scanf("%d", &w);
	
	printf("Area of the rectangle: %d\n", area(l,w));
	printf("Perimeter of the rectangle: %d\n", perimeter(l,w));
	return 0;
}
	
int area(int lenght, int width)
{
	int result =lenght*width;
	return result;
}

int perimeter(int lenght, int width)
{
	int result = 2*(lenght+width);
	return result;
}
