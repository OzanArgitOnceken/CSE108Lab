#include <stdio.h>

int addition(int, int);
int subtraction(int, int);
int multiplication(int, int);
int division(int, int);
int modulus(int, int);

int main()
{
	int a, b, result;
	char operation;
	
	printf("Please enter an operation sign:\n");
	scanf("%c", &operation);
	printf("Please enter two integers:\n");
	scanf("%d %d", &a, &b);
	
	if(operation == '+')
	{
		result = addition(a,b);
		printf("%d + %d = %d\n", a, b, result);
	}
	else if(operation == '-')
	{
		result = subtraction(a,b);
		printf("%d - %d = %d\n", a, b, result);
	}
	else if(operation == '*')
	{
		result = multiplication(a,b);
		printf("%d * %d = %d\n", a, b, result);
	}
	else if(operation == '/')
	{
		result = division(a,b);
		printf("%d / %d = %d\n", a, b, result);
	}
	else if(operation == '%')
	{
		result = modulus(a,b);
		printf("%d = %d (mod%d)\n", a, result, b);
	}
	else
	{
		printf("Error. This operation is not supported.");
	}
	return 0;
}


int addition(int a, int b)
{
	return a+b;
}

int subtraction(int a, int b)
{
	return a-b;
}

int multiplication (int a, int b)
{
	return a*b;
}

int division(int a, int b)
{
	return a/b;
}

int modulus(int a, int b)
{
	return a%b;
}
