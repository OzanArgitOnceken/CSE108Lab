#include <stdio.h>

int main()
{
	int a, b, c, largest;
	printf("Please enter three integer numbers:\n");
	scanf("%d %d %d", &a, &b, &c);
	
	if(a>b)
	{
		largest = a;
	}
	else
	{
		largest = b;
	}
	if(c>largest)
	{
		largest = c;
	}
	printf("The largest number: %d\n", largest);
	return 0;
}
