#include <stdio.h>

void decision(int);

int main()
{
	int number;
	printf("Please enter an integer:\n");
	scanf("%d", &number);
	decision(number);
	return 0;
}

void decision(int number)
{
	int remainder;
	remainder = number % 2;
	if (remainder == 0)
	{
		printf("%d is an even number.\n",number);
	}
	else
	{
		printf("%d is an odd number.\n",number);
	}
}
