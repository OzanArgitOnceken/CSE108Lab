#include <stdio.h>

int check_prime(int a)
{
   int c;
 
   for ( c = 2 ; c <= a - 1 ; c++ )
   { 
      if ( a%c == 0 )
     return 0;
   }
   return 1;
}

int main(void) {

char selection;

printf("a. Is it prime or not\n");
printf("b. Nth prime number\n");
printf("Please select the option from the menu :");
scanf("%c",&selection);
int n, result,m;
int s=1;
switch (selection)
{
  case 'a':
    printf("Enter a positive integer:");
    scanf("%d",&m);
    result=check_prime(m);
    if(result==0)
    {
      printf("%d is not a prime number.",m);
    }
    else
    printf("%d is a prime number.",m);
    break;



  case 'b':
    printf("Enter an integer for N :\n");
    scanf("%d",&m);
      for(int i=2;i<=1000;i++)
      {
        result = check_prime(i);
        if(result==1)
       {
          printf("%d . prime number : %d \n",s,i);
          if(s==m)
        {
          printf("%d.th prime number is %d",m,i);
          break;
        }
        s++;
      }
    }
  }
}