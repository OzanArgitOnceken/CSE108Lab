#include <stdio.h>

int fact(int number)
{
    int i,f=1;
    for(i=1;i<=number;i++)
    {
        f=f*i;
    }
    return f;
}

int combination(int m,int n)
{
  return fact(m)/((fact(n)*fact(m-n)));
}

int permutation(int m,int n)
{
  return fact(m)/fact(m-n);
}

int main(void) {
int m,n,c,p;
 
  	printf("Enter a number (M)\n");
  	scanf("%d",&m);
    printf("Enter a number (N)\n");
  	scanf("%d",&n);
    if(m<n)
    {
      printf("Operation is invalid!");
      
    }
    else
    {
    c=combination(m,n);
    printf("C(%d,%d) = %d\n",m,n,c);
    p=permutation(m,n);
    printf("P(%d,%d) = %d\n",m,n,p);
    }
}