#include <stdio.h>

long fact(int number)
{
    int i;
    long f=1;
    for(i=1;i<=number;i++)
    {
        f=f*i;
    }
    return f;
}

long combination(int m,int n)
{
  return fact(m)/((fact(n)*fact(m-n)));
}

long permutation(int m,int n)
{
  return fact(m)/fact(m-n);
}

int main(void) {
int m,n;
long c,p;
 
  	printf("Enter a number (M)\n");
  	scanf("%d",&m);
    printf("Enter a number (N)\n");
  	scanf("%d",&n);
    if(m<n)
    {
      printf("Operation is invalid!");
      
    }
    else
    {
    c=combination(m,n);
    printf("C(%d,%d) = %ld\n",m,n,c);
    p=permutation(m,n);
    printf("P(%d,%d) = %ld\n",m,n,p);
    }
}