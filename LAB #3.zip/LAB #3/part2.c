#include <stdio.h>

int is_perfect(int number)
{
  int sum=0;
  for(int i=1; i<number; i++){
		if(number%i==0){
			sum = sum + i;
		}
	}
	if(sum == number){
    return 0;
	}
	else{
    return 1;
	}
}

int main(void) {
int number,result;
	printf("Enter the number:\n");
	scanf("%d",&number);
	result=is_perfect(number);
	if(result == 0){
		printf("%d is a perfect number!!\n",number );
	}
	else if(result==1){
		printf("%d isn't a perfect number!!\n",number);
	}
    
}