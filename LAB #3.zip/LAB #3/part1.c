#include <stdio.h>

int main(void) {
  int number1,number2,i;
  printf("Enter the first number:\n");
  scanf("%d",&number1);
  printf("\nEnter the second number:\n");
  scanf("%d",&number2); 
  for(i=1;i<=number2; ++i)
    {
        printf("\n %d * %d = %d \n", number1,i, number1*i);
    }
    
}